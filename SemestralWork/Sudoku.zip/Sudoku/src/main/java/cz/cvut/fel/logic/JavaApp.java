package cz.cvut.fel.logic;

public class JavaApp {
    public static void main(String[] args) {Main.main(args);
    }
}
